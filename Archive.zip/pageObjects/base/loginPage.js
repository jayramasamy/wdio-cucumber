import { config } from '../../wdio.conf';

const EMAIL = '#email';
const PASSWORD = '#password';
const SUBMIT = '#submitButton';

class LoggingPage {
goToLoginPage() {
    return browser.url('/login/');
}
login(email, password) {
    return this.typeUsername(email)
        .then(() => this.typePassword(password))
        .then(this.submit);
}

typeUsername(email) {
    return browser
        .waitForVisible(EMAIL)
        .setValue(EMAIL, username);
}

typePassword(password) {
    return browser
        .waitForVisible(PASSWORD)
        .setValue(PASSWORD, password);
}

submit() {
    return browser.click(SUBMIT);
}
}
export default LoggingPage;
