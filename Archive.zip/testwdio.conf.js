const config = {
    specs: [
        './features/login.feature'
    ],
    capabilities: [{
        browserName: 'chrome'
    }],
    logLevel: 'silent',
    coloredLogs: true,
    baseUrl: 'https://ezakupy.tesco.pl/groceries/en-GB',
    waitforTimeout: 60000,

    reporter: 'spec',
    framework: 'cucumber',
    cucumberOpts: {
      require: ['./features/login.feature', './step_definitions/login.steps.js', './pageObjects/base/loginPage.js' ],
      compiler: ['js:babel-core/register'],   
      ignoreUndefinedDefinitions: false }
   };
  exports.config = config;
