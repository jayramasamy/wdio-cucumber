import cucumber from 'cucumber';
import chai from 'chai';
import wdiocucumberframework from 'wdio-cucumber-framework';

//import chaiAsPromised from 'chai-as-promised';
//chai.use(chaiAsPromised);
//chai.should();
import LoginPage from '../../pageObjects/base/loginPage';
//import MyProfilePage from '../pageObjects/MyProfilePage';

const loginPage = new LoginPage();
//const profilePage = new MyProfilePage();

module.exports = function () {

  this.Given(/^I am on the grocery website$/, () => {
      browser.url('https://wwww.tesco.com/groceries');
    });

  this.Given(/^I go to login page$/,
      loginPage.goToLoginPage()
    );

    this.Given(/^I login with valid credentials$/,
        loginPage.login('jaytestpl1@mailinator.com', 'qwerty123')
    );

    this.Given(/^I should be logged into the grocery site$/,
        loginPage.goToLoginPage()
    );

  };
